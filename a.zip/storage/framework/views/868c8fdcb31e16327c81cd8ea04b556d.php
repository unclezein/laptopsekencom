
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <link href="https://cdn.jsdelivr.net/npm/flowbite@3.1.2/dist/flowbite.min.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@300..700&display=swap" rel="stylesheet">
    <title><?php echo e($title ?? 'TOKOLAPTOPPKU'); ?></title>
    <meta name="description"
        content="<?php echo e($description ?? 'Toko Laptop Seken Terpercaya, Jual Laptop Murah, Laptop Gaming, Laptop untuk Bisnis, Laptop untuk Pribadi di Pekanbaru'); ?>">

    <meta name="keywords"
        content="<?php echo e($keywords . ', Pekanbaru, TOKOLAPTOPPKU, Toko Laptop, Laptop Seken, Laptop Second, Toko Laptop Online, Jual Laptop, Laptop Murah, Laptop Gaming, Laptop Bisnis, Laptop Pribadi'); ?>">
    <meta property="og:title" content="<?php echo e($title ?? 'TOKOLAPTOPPKU'); ?>">
    <meta property="og:description"
        content="<?php echo e($description ?? 'Toko Laptop Seken Terpercaya, Jual Laptop Murah, Laptop Gaming, Laptop untuk Bisnis, Laptop untuk Pribadi di Pekanbaru'); ?>">
    <meta property="og:image" content="<?php echo e($thumbnail ?? asset('asset/img/logo.jpg')); ?>">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:url" content="<?php echo e(request()->url()); ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@tokolaptoppku">
    <meta name="twitter:title" content="<?php echo e($title ?? 'TOKOLAPTOPPKU'); ?>">
    <meta name="twitter:description"
        content="<?php echo e($description ?? 'Toko Laptop Seken Terpercaya, Jual Laptop Murah, Laptop Gaming, Laptop untuk Bisnis, Laptop untuk Pribadi di Pekanbaru'); ?>">
    <meta name="twitter:image" content="<?php echo e($thumbnail ?? asset('asset/img/logo.jpg')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('asset/img/logo.jpg')); ?>" type="image/x-icon">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/flowbite.min.css')); ?>">
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>


    <style>
        .fredoka {
            font-family: "Fredoka", sans-serif;
        }

        /* HTML: <div class="loader"></div> */
        .loader {
            color: #0ea5e9;
            width: 4px;
            aspect-ratio: 1;
            border-radius: 50%;
            box-shadow: 19px 0 0 7px, 38px 0 0 3px, 57px 0 0 0;
            transform: translateX(-38px);
            animation: l21 .5s infinite alternate linear;
        }

        @keyframes l21 {
            50% {
                box-shadow: 19px 0 0 3px, 38px 0 0 7px, 57px 0 0 3px
            }

            100% {
                box-shadow: 19px 0 0 0, 38px 0 0 3px, 57px 0 0 7px
            }
        }
    </style>
</head>

<body class="text-slate-800">
    <section id="global-loader"
        class="hidden bg-white/80 h-screen w-full fixed z-[100] top-0 left-0 flex justify-center items-center">
        <div class="loader"></div>
    </section>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loader = document.getElementById('global-loader');

            document.querySelectorAll('a[href]').forEach(link => {
                const href = link.getAttribute('href');

                // Abaikan link kosong, #, atau javascript:void(0)
                if (!href || href.startsWith('#') || href.startsWith('javascript')) return;

                link.addEventListener('click', function(e) {
                    // Abaikan klik jika pakai Ctrl/Meta (cmd)/Shift (tab baru)
                    if (e.ctrlKey || e.metaKey || e.altKey || e.shiftKey) return;

                    // Cek apakah link eksternal (beda host)
                    const isExternal = this.hostname !== window.location.hostname;

                    if (!isExternal) {
                        // Jika internal, tampilkan loader
                        loader.classList.remove('hidden');
                    }
                });
            });
        });
    </script>
    <?php echo e($slot); ?> 
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <script src="<?php echo e(asset('asset/js/flowbite.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\Users\ux\Desktop\laptopseken\laptopsekencom\resources\views/product-detail.blade.php ENDPATH**/ ?>