<?php $__env->startSection('title', 'TOKOLAPTOPPKU'); ?>
<?php $__env->startSection('menu-home'); ?>
    text-blue-800 fill-blue-800
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('woo-product-list-home');

$__html = app('livewire')->mount($__name, $__params, 'lw-82631072-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ux\Desktop\laptopseken\laptopsekencom\resources\views/index.blade.php ENDPATH**/ ?>