<!doctype html>
<html>

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <link href="https://cdn.jsdelivr.net/npm/flowbite@3.1.2/dist/flowbite.min.css" rel="stylesheet" />
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('asset/css/flowbite.min.css')); ?>">
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body class="text-slate-700 flex justify-between">
    <aside class="w-[360px] bg-white h-screen border border-gray-300 shadow-lg">
        <div class="p-5 font-bold text-xl">
            DASHBOARD ADMIN
        </div>
        <div>
            <a href="#"
                class="block w-full p-5 hover:bg-blue-500 rounded-md font-semibold duration-300 ease-in-out hover:text-white bg-blue-500 text-white">Dashboard</a>
            <a href="#"
                class="block w-full p-5 hover:bg-blue-500 rounded-md font-semibold duration-300 ease-in-out hover:text-white">Merk</a>
            <a href="#"
                class="block w-full p-5 hover:bg-blue-500 rounded-md font-semibold duration-300 ease-in-out hover:text-white">Laptop</a>
        </div>
    </aside>
    <main class="w-full">
        <section class="p-5">
            <div class="p-5 border border-gray-300 rounded-lg mb-5">
                <div class=" mb-5">
                    <h2 class="text-2xl font-bold">Tambah Laptop</h2>
                </div>
                <form action="<?php echo e(route('admin.store-merk')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <div class="mb-6">
                        <label for="nama" class="block mb-2 text-sm font-medium text-gray-900">Merk</label>
                        <input type="text" id="merk" name="merk"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                            placeholder="merk" required>
                            <p class="text-red-500 text-xs mt-1"> <?php echo e($errors->first('merk')); ?></p>
                    </div>
                    <button type="submit"
                        class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center">Tambah</button>
                </form>
            </div>
        </section>
    </main>
    <?php if(session()->has('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil',
                text: '<?php echo e(session()->get('success')); ?>',
                showConfirmButton: false,
                timer: 1500
            })
        </script>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Gagal',
                text: '<?php echo e(session()->get('error')); ?>',
                showConfirmButton: false,
                timer: 1500
            })
        </script>
    <?php endif; ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <script src="<?php echo e(asset('asset/js/flowbite.min.js')); ?>"></script>
</body>

</html>

<?php /**PATH C:\Users\ux\Desktop\laptopseken\laptopsekencom\resources\views/admin/tambah-merk.blade.php ENDPATH**/ ?>