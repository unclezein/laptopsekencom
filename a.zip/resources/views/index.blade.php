@extends('layout.master')
@section('title', 'TOKOLAPTOPPKU')
@section('menu-home')
    text-blue-800 fill-blue-800
@endsection
@section('content')
    @livewire('woo-product-list-home')
@endsection
