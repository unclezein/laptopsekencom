@extends('layout.master')
@section('menu-search')
    text-blue-800 fill-blue-800
@endsection

@section('content')
    @livewire('woo-product-list')
@endsection
